<?php
    class Pagamento{
        private $tipoPagamento;

        public function getTipoPagamento(){
            return $this->tipoPagamento;
        }

        public function setTipoPagamento($tipoPagamento){
            $this->tipoPagamento = $tipoPagamento;
        }
    }