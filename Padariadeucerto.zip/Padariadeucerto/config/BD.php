<?php
    class BD {
        public static function getConexao() {
            $conn = new PDO(
                "mysql:host=localhost;dbname=bdpadaria",
                "root",
                "root"
            );

            return $conn;
        }
    }